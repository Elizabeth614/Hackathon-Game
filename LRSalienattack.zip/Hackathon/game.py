# Import all necessary libraries
import pygame
from pygame.locals import (
    K_UP,
    K_DOWN,
    K_LEFT,
    K_RIGHT,
    K_ESCAPE,
    KEYDOWN,
    QUIT,
)

# Initialize pygame
pygame.init()

# Create screen and dimensions using display.set_mode(dimensions)
screen = pygame.display.set_mode((1002, 500))
# Name the window
pygame.display.set_caption("Alien Attack")
# Import and scale sprite textures
character = pygame.image.load("char.png")
character = pygame.transform.scale(character, (100, 200))
alien1 = pygame.image.load("alien1.png")
alien1 = pygame.transform.scale(alien1, (150, 135))


# Create player class
class Player:
    def __init__(self, x, y, width, height):
        # Sets attributes of the object including: x and y positions, width and height, velocity, movement, and hitbox.
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 5
        self.left = False
        self.right = False
        self.walkCount = 0
        self.hitbox = (self.x, self.y, 100, 200)
    
    # Define a function that allows the player to be seen on the screen
    def draw(self, screen):
        if self.walkCount + 1 >= 27:
            self.walkCount = 0
        if self.left:
            screen.blit(character, (self.x, self.y))
            self.walkCount += 1
        elif self.right:
            screen.blit(character, (self.x, self.y))
            self.walkCount += 1
        else:
            screen.blit(character, (self.x, self.y))
        self.hitbox = (self.x, self.y, 100, 200)

# Create a class for the projectiles that the player can shoot
class Projectile(object):
    # Set attributes for position, radius, and the direction that the bullet will be shot
    def __init__(self, x, y, facing, radius):
        self.x = x
        self.y = y
        self.facing = facing
        self.vel = 8 * facing
        self.radius = radius
    
    # Draws the projectile onto the screen
    def draw(self, screen):
        projectileImage = pygame.image.load("LRS1.png")
        projectileImage = pygame.transform.scale(projectileImage, (50, 50))
        screen.blit(projectileImage, (self.x, self.y))

# Create a class for the aliens
class Alien(object):
    # Sets attributes of the object including: x and y positions, width and height, velocity, movement, hitbox, and health.
    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 2
        self.walkCount = 0
        self.end = end
        self.path = [self.end, self.x]
        self.hitbox = (self.x, self.y, 100, 100)
        self.health = 10
        self.visible = True

    # Draws the alien onto the screen, draws its healthbar
    def draw(self, screen):
        self.move()
        if self.visible:
            screen.blit(alien1, (self.x, self.y))
            self.hitbox = (self.x, self.y, 150, 135)

            pygame.draw.rect(screen, (255, 0, 0), (self.hitbox[0], self.hitbox[1] - 20, 150, 10))
            pygame.draw.rect(screen, (0, 255, 0), (self.hitbox[0], self.hitbox[1] - 20, 150 - (15 * (10 - self.health)), 10))

    # Automates the movement of the alien
    def move(self):
        if self.vel > 0:
            if self.x + self.vel < self.path[1]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1
                self.walkCount = 0
        else:
            if self.x - self.vel > self.path[0]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1
                self.walkCount = 0

    # Reduces health when hit and makes the alien invisible (dead) when it's health reaches 0
    def hit(self):
        if self.health > 0:
            self.health -= 1
        else:
            self.visible = False

score = 0 # Variable to store the player's score

# Called at the end of loop to refresh the game screen so that it updates every frame
def redrawGameWindow():
    global score
    bg = pygame.image.load("bg.png")
    screen.blit(bg, (0, 0))
    text = font.render("Score: " + str(score), 1, (0,0,0))
    screen.blit(text, (850, 10))
    char.draw(screen)
    alien.draw(screen)
    for bullet in bullets:
        bullet.draw(screen)
    pygame.display.update()

# Function to show the main menu screen
def menu():
    bg = pygame.image.load("menu.jpg") # Displays the background

    running = True
    while running:
        screen.blit(bg, (0, 0))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT: # Create a condition to end the game
                running = False
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.pos[0] in range(368, 610) and event.pos[1] in range(267, 353): # Map region for play button
                    game() # Starts game
# Loads background for the win screen.
def won():
    bg = pygame.image.load("won.png") 

    running = True
    while running:
        screen.blit(bg, (0, 0))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.pos[0] in range(368, 610) and event.pos[1] in range(267, 353): # Map region for play button
                    game()

# Define variables to store font, instances of objects, and variables for counting (bullets, enemies, and count)
font = pygame.font.SysFont("poppins", 30, True)
char = Player(100, 250, 64, 64)
alien = Alien(900, 300, 64, 64, 30)
bullets = []
enemies = [alien]
count = 0


def game():
    # Make alien and score accessible throughout the function
    global alien
    global score
    levelbg = pygame.image.load("bg.png") # Load background
    running = True
    shootLoop = 0

    while running:
        # Controls the rate at which the player can shoot projectiles
        if shootLoop > 0:
            shootLoop += 1
        if shootLoop > 3:
            shootLoop = 0

        # Adds a new enemy every time the player kills one
        for enemy in enemies:
            if enemy.visible == False:
                enemies.pop(enemies.index(enemy))
                alien = Alien(900, 300, 64, 64, 30)
                enemies.append(alien)

        # Allows the player to quit the game without program error
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()

        # Detects if the bullet hits the alien or if the bullet reaches the end of either side of the screen. Removes the bullet if any of the scenarios occur
        for bullet in bullets:
            if alien.visible == True:
                if bullet.y - bullet.radius < alien.hitbox[1] + alien.hitbox[3] and bullet.y + bullet.radius > alien.hitbox[1]:
                    if bullet.x + bullet.radius > alien.hitbox[0] and bullet.x - bullet.radius < alien.hitbox[0] + alien.hitbox[2]:
                        alien.hit()
                        score += 1
                        bullets.pop(bullets.index(bullet))

            if bullet.x < 1002 and bullet.x > 0:
                bullet.x += bullet.vel
            else:
                bullets.pop(bullets.index(bullet))

        # Gets list of key presses
        keys = pygame.key.get_pressed()

        # Makes the player move left when the left arrow key is pressed, right when the right arrow key is pressed
        if keys[pygame.K_LEFT] and char.x > char.vel:
            char.x -= char.vel
            char.left = True
            char.right = False
        elif keys[pygame.K_RIGHT] and char.x < 750 - char.width - char.vel:
            char.x += char.vel
            char.left = False
            char.right = True
        
        # Allows the player to shoot a bullet when the spacebar is pressed
        if keys[pygame.K_SPACE] and shootLoop == 0:
            if char.left:
                facing = -1
            else:
                facing = 1
            if len(bullets) < 5:
                bullets.append(Projectile(round(char.x + char.width // 2), round(char.y + char.height // 2), facing, 25))
            
            shootLoop = 1

        # Once the player's score reaches 200, they win, so the won() function is called to display the win screen
        if score >= 200:
            won()

        redrawGameWindow()

# Call the menu to load the game
menu()

# Sources:
# https://www.techwithtim.net/tutorials/game-development-with-python/pygame-tutorial
# https://www.pygame.org/docs/
# https://www.youngwonks.com/blog/How-to-Make-a-Side-Scroller-Game-using-Python-and-PyGame
# https://realpython.com/courses/pygame-primer/